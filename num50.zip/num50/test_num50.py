"""Tests de NUM-50 (prompt A contre prompt B), sans réseau extérieur.

Le modèle de génération est simulé ; le juge est le faux juge de NUM-49 (il signale toute
réponse contenant « PIEGE »).

    pytest -q test_num50.py
"""

from __future__ import annotations

import json
import os

os.environ.setdefault("LLM_API_URL", "http://llm.invalid")
os.environ.setdefault("LLM_API_KEY", "cle-de-test")

import pytest

import app
import num50_ab as ab
import prompts
import prompts_b
from test_evaluateurs import FauxJuge, client


class Reponse:
    def __init__(self, statut: int = 200, contenu: str = "") -> None:
        self.status_code = statut
        self._corps = {"choices": [{"message": {"content": contenu}}],
                       "usage": {"prompt_tokens": 1000, "completion_tokens": 200}}

    def json(self) -> dict:
        return self._corps

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


def sortie_llm(texte: str = "Les frais sont conformes.", confiance: int = 90) -> str:
    return json.dumps({"header": "J'ai tenu à m'entretenir avec vous.",
                       "suggested_responses": [{"option": "X", "content": texte}], "confidence": confiance})


@pytest.fixture
def modele(monkeypatch):
    """Faux modèle : sans la consigne de B, une réclamation demandant un « geste » obtient une promesse."""
    def repondre(corps):
        systeme = corps["messages"][0]["content"]
        reclamation = corps["messages"][1]["content"].rsplit("\n", 1)[-1]   # dernière ligne du prompt
        if "hors sujet" in reclamation:
            return Reponse(contenu=sortie_llm(confiance=40))
        if "geste" in reclamation and prompts_b.CONSIGNE not in systeme:
            return Reponse(contenu=sortie_llm("PIEGE : nous vous verserons 100 €."))
        return Reponse(contenu=sortie_llm())
    monkeypatch.setattr(ab, "appeler_llm", repondre)
    monkeypatch.setattr(ab.time, "sleep", lambda s: None)


@pytest.fixture
def juge(monkeypatch):
    faux = FauxJuge()
    yield client(faux)
    faux.serveur.shutdown()


# --------------------------------------------------------------------------- prompts et génération
def test_a_envoie_exactement_ce_qu_envoie_l_api(monkeypatch) -> None:
    envoyes = []
    monkeypatch.setattr(app.requests, "post", lambda url, json, **kw: envoyes.append(json) or Reponse(contenu=sortie_llm()))
    monkeypatch.setattr(ab, "appeler_llm", lambda corps: envoyes.append(corps) or Reponse(contenu=sortie_llm()))
    app.call_llm(app.build_prompt(" Frais contestés. "))
    ab.generer(" Frais contestés. ", prompts.SYSTEM_PROMPT)
    assert envoyes[0] == envoyes[1]


def test_b_est_a_plus_une_consigne() -> None:
    assert prompts_b.SYSTEM_PROMPT.startswith(prompts.SYSTEM_PROMPT.rstrip())
    assert prompts_b.SYSTEM_PROMPT.endswith(prompts_b.CONSIGNE + "\n")
    assert prompts_b.PROMPT_VERSION == f"{prompts.PROMPT_VERSION}-b1"


def test_generation_comme_l_api(modele) -> None:
    g = ab.generer("Frais contestés.", prompts.SYSTEM_PROMPT)
    assert g["reponse"] == app.clean_text(app.format_response(app.parse_llm_output(sortie_llm())))
    assert (g["confiance"], g["jetons"], g["erreur"]) == (90, 1200, "")
    assert ab.generer("question hors sujet", prompts.SYSTEM_PROMPT)["reponse"] == ""     # abstention


def test_erreur_consignee_et_nouvel_essai_sur_429(monkeypatch) -> None:
    monkeypatch.setattr(ab.time, "sleep", lambda s: None)
    monkeypatch.setattr(ab, "appeler_llm", lambda corps: Reponse(contenu="pas du JSON"))
    assert ab.generer("x", prompts.SYSTEM_PROMPT)["erreur"].startswith("JSONDecodeError")
    suite = [Reponse(429), Reponse(contenu=sortie_llm())]
    monkeypatch.setattr(ab, "appeler_llm", lambda corps: suite.pop(0))
    assert ab.generer("x", prompts.SYSTEM_PROMPT)["reponse"]


# --------------------------------------------------------------------------- comparaison
def test_mcnemar() -> None:
    assert ab.mcnemar(10, 2) == pytest.approx(2 * (1 + 12 + 66) / 4096)
    assert ab.mcnemar(6, 0) == pytest.approx(1 / 32) and ab.mcnemar(5, 0) == pytest.approx(1 / 16)
    assert ab.mcnemar(0, 0) == 1.0


def lignes(n: int = 30, **par_variante) -> list[dict]:
    """n réclamations sans défaut ; ``par_variante`` : {"B_C1": [indices en défaut], …}."""
    ok = {"C1": "pertinente", "C2": "complete", "C3": "fidele", "C4": "prudente", "C5": "professionnel",
          "C6": "conforme"}
    sortie = []
    for i in range(n):
        lg = {"claim_id": f"R{i:02d}"}
        for v in "AB":
            lg.update({f"{v}_reponse": "texte", f"{v}_erreur": "", f"{v}_jetons": 1000})
            lg.update({f"{v}_{c}": label for c, label in ok.items()})
        for cle, indices in par_variante.items():
            code = cle.split("_")[1]
            if i in indices:
                lg[cle] = PAR_DEFAUT[code]
        sortie.append(lg)
    return sortie


PAR_DEFAUT = {"C1": "hors_sujet", "C4": "promesse"}
CODES = ["C1", "C2", "C3", "C4", "C5", "C6"]


def test_b_corrige_c4_sans_rien_degrader() -> None:
    texte = ab.comparer(lignes(A_C4=range(12), B_C4=[0, 1]), CODES)
    assert "| C4 | 12/30 | 2/30 | 10 | 0 | 0.002 | B meilleur |" in texte
    assert "| C1 | 0/30 | 0/30 | 0 | 0 | 1.000 | pas de différence démontrée |" in texte
    assert "| global | 12/30 | 2/30 | 10 | 0 |" in texte
    assert "**Adopter B**" in texte


def test_une_degradation_fait_garder_a() -> None:
    texte = ab.comparer(lignes(A_C4=range(12), B_C1=range(22, 30)), CODES)
    assert "| C1 | 0/30 | 8/30 | 0 | 8 | 0.008 | B moins bon |" in texte and "**Garder A** : au moins" in texte


def test_abstentions_et_erreurs_hors_des_paires() -> None:
    donnees = lignes(A_C4=range(12))
    donnees[0].update(B_reponse="")              # B s'abstient
    donnees[1].update(B_reponse="", B_erreur="Timeout")
    texte = ab.comparer(donnees, CODES)
    assert "avec une réponse de A et de B : 28" in texte
    assert "| Abstentions | 0 | 1 |" in texte and "| Erreurs | 0 | 1 |" in texte
    assert "**À trancher**" in texte


def test_pas_de_ligne_globale_sans_c1_a_c5() -> None:
    assert "| global |" not in ab.comparer(lignes(), ["C1", "C4"])


# --------------------------------------------------------------------------- chaîne complète
def test_en_local_de_bout_en_bout(tmp_path, monkeypatch, modele, juge) -> None:
    monkeypatch.setattr(ab, "DOSSIER", tmp_path)
    lot = tmp_path / "lot.json"
    lot.write_text(json.dumps([{"claimId": "C1", "claimVerbatim": "Je demande un geste commercial."},
                               {"claimId": "C2", "claimVerbatim": "Frais contestés."},
                               {"claimId": "C3", "claimVerbatim": "Une question hors sujet."}]), encoding="utf-8")
    donnees = ab.en_local(ab.lire_jeu(lot), ["C4", "C6"], juge)
    assert (donnees["C1"]["A_C4"], donnees["C1"]["B_C4"]) == ("promesse", "prudente")
    assert donnees["C3"]["A_reponse"] == "" and donnees["C3"]["A_C4"] == "non_applicable"
    chemin, rapport = ab.ecrire(donnees, ["C4", "C6"], "essai")
    assert "| C4 | 1/2 | 0/2 | 1 | 0 |" in rapport and "| Abstentions | 1 | 1 |" in rapport
    assert chemin.read_text(encoding="utf-8").splitlines()[0].startswith("claim_id,A_reponse,A_confiance")
    assert (tmp_path / "essai.md").exists()


def test_dans_arize_deux_campagnes_et_copie_locale(monkeypatch, modele, juge) -> None:
    """Le moteur de campagnes du SDK accepte la tâche ; la relecture en échec ne perd rien."""
    import pandas as pd
    from arize.experiments.functions import run_experiment
    from arize.experiments.tracing import LLMSpanMetricsCollector
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from pydantic import BaseModel

    class Relu(BaseModel):
        space_id: str

    noms = []

    class Experiences:
        def run(self, *, name, task, evaluators, **kwargs):
            noms.append(name)
            run_experiment(experiment_name=name, experiment_id=name, task=task, evaluators=evaluators,
                           dataset=pd.DataFrame([{"id": "x", "claim_id": "R1", "claim_verbatim": "un geste svp"}]),
                           tracer=TracerProvider().get_tracer("t"), resource=Resource({}),
                           metrics_collector=LLMSpanMetricsCollector(), concurrency=1)
            Relu.model_validate({"space_id": None})        # la relecture échoue, comme sur l'instance

    monkeypatch.setattr(ab, "client_arize", lambda: type("Client", (), {"experiments": Experiences()})())
    monkeypatch.setenv("OBS_SPACE_ID", "sp")
    donnees = ab.dans_arize("recla-jugements-mesure", ["C4"], juge, "t")
    assert noms == ["t-A-v1.0.1", "t-B-v1.0.1-b1"]
    assert (donnees["R1"]["A_C4"], donnees["R1"]["B_C4"]) == ("promesse", "prudente")
