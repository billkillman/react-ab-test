"""Compare le prompt A (l'API) et le prompt B (``prompts_b.py``) sur les mêmes réclamations (NUM-50).

Pour chaque réclamation, A et B génèrent une réponse, et le juge de NUM-49 note les deux.
Seul le prompt système change : la réclamation est insérée dans le prompt de l'API
(``app.build_prompt``) ; modèle, paramètres, seuil de confiance et mise en forme sont ceux de
l'API.

    python num50_ab.py --fichier lot_C_promesses.json --nombre 3    essai local sur 3 réclamations
    python num50_ab.py --fichier lot_C_promesses.json               tout le lot, en local
    python num50_ab.py --jeu recla-jugements-mesure                  deux campagnes Arize : A puis B

Sorties, dans ``num50_resultats/`` :
    <nom>.csv   une ligne par réclamation, A et B côte à côte (réponse, étiquettes, jetons)
    <nom>.md    le tableau de comparaison et la décision

Hors production, ``JUGE_INTERVALLE_S`` espace tous les appels au service (génération
comprise) : le quota est partagé.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
import time
from pathlib import Path

import requests

import app
import prompts
import prompts_b
from forme import verifier_forme
from grille import GRILLE, PAR_CODE
from juge import ClientJuge, juger
from num51_lancer import FormeJournalisee, JugeJournalise, client_arize

VARIANTES = {"A": (prompts.SYSTEM_PROMPT, prompts.PROMPT_VERSION),
             "B": (prompts_b.SYSTEM_PROMPT, prompts_b.PROMPT_VERSION)}
JUGES = ["C1", "C2", "C3", "C4", "C5"]
DOSSIER = Path("num50_resultats")


# =============================================================================
# 1. Générer une réponse avec un prompt système donné
# =============================================================================
def appeler_llm(corps: dict) -> requests.Response:
    return requests.post(f"{app.LLM_URL}/v1/chat/completions", json=corps, timeout=60, verify=app.CA_BUNDLE,
                         headers={"Authorization": f"Bearer {app.LLM_API_KEY}"})


def generer(reclamation: str, systeme: str, attendre=lambda: None) -> dict:
    """La réponse de l'API, avec ce prompt système. Une erreur est consignée, jamais levée."""
    corps = {"model": app.MODEL_NAME,
             "messages": [{"role": "system", "content": systeme},
                          {"role": "user", "content": app.build_prompt(reclamation).strip()}],
             **app.GENERATION_PARAMS}
    try:
        for essai in range(3):                  # hors production : jusqu'à deux nouveaux essais sur 429
            attendre()
            reponse = appeler_llm(corps)
            if reponse.status_code != 429 or essai == 2:
                break
            time.sleep(10 * (essai + 1))
        reponse.raise_for_status()
        donnees = reponse.json()
        lu = app.parse_llm_output(donnees["choices"][0]["message"]["content"])
        texte = app.clean_text(app.format_response(lu)) if lu.confidence >= app.CONFIDENCE_THRESHOLD else ""
        usage = donnees.get("usage") or {}
        jetons = (usage.get("prompt_tokens") or 0) + (usage.get("completion_tokens") or 0)
        return {"reponse": texte, "confiance": lu.confidence, "jetons": jetons, "erreur": ""}
    except Exception as exc:  # noqa: BLE001 - la réclamation est marquée en erreur, la comparaison continue
        return {"reponse": "", "confiance": "", "jetons": "", "erreur": f"{type(exc).__name__}: {exc}"[:200]}


# =============================================================================
# 2. Noter, par réclamation, ce que produit chaque variante
# =============================================================================
class Carnet:
    """Écrit les résultats d'une variante (A ou B) dans le tableau commun, une ligne par réclamation."""

    def __init__(self, variante: str, lignes: dict[str, dict]) -> None:
        self.variante, self.lignes = variante, lignes

    def _ligne(self, row: dict) -> dict:
        cid = str(row.get("claim_id"))
        return self.lignes.setdefault(cid, {"claim_id": cid})

    def generation(self, row: dict, g: dict) -> None:
        self._ligne(row).update({f"{self.variante}_{k}": v for k, v in g.items()})

    def noter(self, row: dict, code: str, label: str | None, score=None, explication=None) -> None:
        self._ligne(row)[f"{self.variante}_{code}"] = label or ""


# =============================================================================
# 3. Faire tourner A puis B : en local, ou comme campagnes Arize
# =============================================================================
def en_local(reclamations: list[dict], codes: list[str], juge: ClientJuge) -> dict[str, dict]:
    lignes: dict[str, dict] = {}
    for variante, (systeme, _) in VARIANTES.items():
        carnet = Carnet(variante, lignes)
        for rang, row in enumerate(reclamations, start=1):
            print(f"  {variante} {rang}/{len(reclamations)}", end="\r", flush=True)
            g = generer(row["claim_verbatim"], systeme, juge._attendre_son_tour)
            carnet.generation(row, g)
            for code in codes:
                v = (verifier_forme(g["reponse"]) if code == "C6"
                     else juger(PAR_CODE[code], row["claim_verbatim"], g["reponse"], juge))
                carnet.noter(row, code, v.label)
    print()
    return lignes


def dans_arize(jeu: str, codes: list[str], juge: ClientJuge, nom: str) -> dict[str, dict]:
    from pydantic import ValidationError

    lignes: dict[str, dict] = {}
    for variante, (systeme, version) in VARIANTES.items():
        carnet = Carnet(variante, lignes)

        def tache(dataset_row: dict, systeme: str = systeme, carnet: Carnet = carnet) -> str:
            g = generer(str(dataset_row.get("claim_verbatim") or ""), systeme, juge._attendre_son_tour)
            carnet.generation(dataset_row, g)
            return g["reponse"]

        evaluateurs = [FormeJournalisee(carnet) if c == "C6" else JugeJournalise(PAR_CODE[c], juge, carnet)
                       for c in codes]
        campagne = f"{nom}-{variante}-v{version}"
        print(f"Campagne « {campagne} » sur « {jeu} »…")
        try:
            client_arize().experiments.run(name=campagne, dataset=jeu, space=os.environ["OBS_SPACE_ID"],
                                           task=tache, evaluators=evaluateurs, concurrency=1,
                                           exit_on_error=False, timeout=600)
        except ValidationError:
            pass    # relecture de la campagne par le SDK en échec (connu depuis NUM-49) : résultats enregistrés
    return lignes


# =============================================================================
# 4. Comparer, par paires
# =============================================================================
def mcnemar(corrigees: int, degradees: int) -> float:
    """p-valeur exacte : sans effet de B, chaque divergence irait d'un côté ou de l'autre à pile ou face."""
    n = corrigees + degradees
    if n == 0:
        return 1.0
    return min(1.0, 2 * sum(math.comb(n, k) for k in range(min(corrigees, degradees) + 1)) / 2 ** n)


def en_defaut(ligne: dict, variante: str, portee: str) -> bool | None:
    """Défaut sur ce critère (ou sur C1 à C5 pour « global ») ; None si illisible."""
    codes = JUGES if portee == "global" else [portee]
    verdicts = []
    for code in codes:
        label = ligne.get(f"{variante}_{code}")
        if label not in (PAR_CODE[code].positif, PAR_CODE[code].negatif):
            return None
        verdicts.append(label == PAR_CODE[code].negatif)
    return any(verdicts)


def comparer(lignes: list[dict], codes: list[str]) -> str:
    repond = [lg for lg in lignes if all(lg.get(f"{v}_reponse") and not lg.get(f"{v}_erreur") for v in "AB")]
    portees = codes + (["global"] if all(c in codes for c in JUGES) else [])
    o = ["| Critère | Défauts A | Défauts B | Corrigées par B | Dégradées par B | p | Verdict |",
         "|---|---|---|---|---|---|---|"]
    verdicts = []
    for portee in portees:
        paires = [(en_defaut(lg, "A", portee), en_defaut(lg, "B", portee)) for lg in repond]
        paires = [(a, b) for a, b in paires if a is not None and b is not None]
        corrigees = sum(a and not b for a, b in paires)
        degradees = sum(b and not a for a, b in paires)
        p = mcnemar(corrigees, degradees)
        verdict = ("B meilleur" if corrigees > degradees else "B moins bon") if p < 0.05 else "pas de différence démontrée"
        verdicts.append(verdict)
        o.append(f"| {portee} | {sum(a for a, _ in paires)}/{len(paires)} | {sum(b for _, b in paires)}/{len(paires)} "
                 f"| {corrigees} | {degradees} | {p:.3f} | {verdict} |")

    abstentions = {v: sum(not lg.get(f"{v}_reponse") and not lg.get(f"{v}_erreur") for lg in lignes) for v in "AB"}
    erreurs = {v: sum(bool(lg.get(f"{v}_erreur")) for lg in lignes) for v in "AB"}

    def jetons(v: str) -> str:
        valeurs = [float(lg[f"{v}_jetons"]) for lg in repond if lg.get(f"{v}_jetons") not in ("", None)]
        return f"{sum(valeurs) / len(valeurs):.0f}" if valeurs else "—"

    if "B moins bon" in verdicts:
        decision = "**Garder A** : au moins un critère est dégradé par B."
    elif "B meilleur" in verdicts and abstentions["B"] > abstentions["A"]:
        decision = "**À trancher** : B améliore un critère, mais s'abstient plus souvent que A."
    elif "B meilleur" in verdicts:
        decision = "**Adopter B** : au moins un critère amélioré, aucun dégradé."
    else:
        decision = "**Garder A** : aucune différence démontrée."
    o += ["", f"Réclamations : {len(lignes)} ; avec une réponse de A et de B : {len(repond)}.", "",
          "| | A | B |", "|---|---|---|",
          f"| Abstentions | {abstentions['A']} | {abstentions['B']} |",
          f"| Erreurs | {erreurs['A']} | {erreurs['B']} |",
          f"| Jetons par réponse (moyenne) | {jetons('A')} | {jetons('B')} |", "",
          f"Décision : {decision}"]
    return "\n".join(o) + "\n"


# =============================================================================
# 5. Lancer
# =============================================================================
def lire_jeu(fichier: Path) -> list[dict]:
    """CSV du NUM-14 (claim_id, claim_verbatim) ou lot JSON du NUM-110 (claimId, claimVerbatim)."""
    if fichier.suffix.lower() == ".json":
        return [{"claim_id": r["claimId"], "claim_verbatim": r["claimVerbatim"]}
                for r in json.loads(fichier.read_text(encoding="utf-8"))]
    with fichier.open(encoding="utf-8", newline="") as flux:
        return list(csv.DictReader(flux))


def ecrire(lignes: dict[str, dict], codes: list[str], nom: str) -> tuple[Path, str]:
    DOSSIER.mkdir(exist_ok=True)
    colonnes = ["claim_id"] + [f"{v}_{c}" for v in "AB" for c in ["reponse", "confiance", "jetons", "erreur", *codes]]
    chemin = DOSSIER / f"{nom}.csv"
    with chemin.open("w", encoding="utf-8", newline="") as flux:
        ecrivain = csv.DictWriter(flux, fieldnames=colonnes, extrasaction="ignore")
        ecrivain.writeheader()
        ecrivain.writerows(lignes[c] for c in sorted(lignes))
    entete = (f"# NUM-50 — {nom}\n\nA : version {VARIANTES['A'][1]} ; B : version {VARIANTES['B'][1]}.\n\n")
    rapport = entete + comparer(list(lignes.values()), codes)
    (DOSSIER / f"{nom}.md").write_text(rapport, encoding="utf-8")
    return chemin, rapport


def main() -> int:
    parser = argparse.ArgumentParser(description="Compare le prompt A (API) et le prompt B (prompts_b.py).")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--fichier", type=Path, help="jeu local (CSV ou lot JSON) : exécution locale")
    source.add_argument("--jeu", help="jeu de données Arize : deux campagnes, A puis B")
    parser.add_argument("--nombre", type=int, default=0, help="en local : limiter à N réclamations")
    parser.add_argument("--criteres", default=",".join(c.code for c in GRILLE),
                        help="critères jugés (défaut : C1 à C6 ; ne garder que ceux jugés fiables en NUM-51)")
    args = parser.parse_args()

    codes = [c.strip().upper() for c in args.criteres.split(",") if c.strip()]
    if inconnus := [c for c in codes if c not in PAR_CODE]:
        raise SystemExit(f"Critères inconnus : {inconnus}.")
    juge = ClientJuge()
    if args.fichier:
        reclamations = lire_jeu(args.fichier)[: args.nombre or None]
        nom = f"num50-{args.fichier.stem}-{time.strftime('%Y%m%d-%H%M%S')}"
        lignes = en_local(reclamations, codes, juge)
    else:
        nom = f"num50-{args.jeu}-{time.strftime('%Y%m%d-%H%M%S')}"
        lignes = dans_arize(args.jeu, codes, juge, nom)
    chemin, rapport = ecrire(lignes, codes, nom)
    print(rapport)
    print(f"Détail par réclamation : {chemin}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
