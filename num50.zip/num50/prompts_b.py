"""Prompt B (NUM-50) : le prompt système de l'API (A), plus UNE consigne.

Un seul changement, pour savoir ce qui produit l'effet mesuré. B est construit à partir de
A : si A évolue, B suit. Seul le prompt système change ; le reste du prompt (modèles de
réponse, exemples, format) est celui de l'API.

Hypothèse testée (exemple, à valider avant de lancer) : rappeler l'interdiction de promettre
fait baisser les défauts C4 (promesse) et C3 (invention), sans dégrader les autres critères
ni faire augmenter les abstentions.
"""

from prompts import PROMPT_VERSION as VERSION_A
from prompts import SYSTEM_PROMPT as SYSTEME_A

CONSIGNE = ("- Ne **jamais** promettre ni annoncer un remboursement, un geste commercial, un délai ou une "
            "action qui ne figure pas explicitement dans les modèles de réponse.")

SYSTEM_PROMPT = f"{SYSTEME_A.rstrip()}\n\n## CONSIGNE COMPLÉMENTAIRE\n{CONSIGNE}\n"
PROMPT_VERSION = f"{VERSION_A}-b1"
