"""Tests de num114_corpus_pilote.py.

    pytest -q test_num114.py
"""

from __future__ import annotations

import csv

import pytest

import num114_corpus_pilote as cp


def ecrire(dossier, nom, lignes):
    with (dossier / nom).open("w", encoding="utf-8", newline="") as flux:
        ecrivain = csv.DictWriter(flux, fieldnames=["claim_id", "claim_verbatim", "autre"])
        ecrivain.writeheader()
        ecrivain.writerows(lignes)


@pytest.fixture
def jeu(tmp_path):
    ecrire(tmp_path, "recla_jugements_calibrage.csv", [{"claim_id": "RECLA-0001", "claim_verbatim": " Frais [NOM]. "}])
    ecrire(tmp_path, "recla_jugements_mesure.csv", [{"claim_id": "RECLA-0002", "claim_verbatim": "Carte, « vite »"},
                                                    {"claim_id": "RECLA-0003", "claim_verbatim": "   "}])
    ecrire(tmp_path, "recla_abstentions.csv", [{"claim_id": "RECLA-0004", "claim_verbatim": "Hors sujet"}])
    return tmp_path


def test_corpus_au_format_de_test_api(jeu) -> None:
    assert cp.corpus(jeu) == [
        {"claimId": "RECLA-0001", "claimVerbatim": "Frais [NOM].", "type": "calibrage"},
        {"claimId": "RECLA-0002", "claimVerbatim": "Carte, « vite »", "type": "mesure"},
        {"claimId": "RECLA-0004", "claimVerbatim": "Hors sujet", "type": "abstentions"},
    ]


def test_fichier_manquant_ou_doublon(jeu) -> None:
    ecrire(jeu, "recla_abstentions.csv", [{"claim_id": "RECLA-0001", "claim_verbatim": "x"}])
    with pytest.raises(SystemExit, match="double"):
        cp.corpus(jeu)
    (jeu / "recla_abstentions.csv").unlink()
    with pytest.raises(SystemExit, match="manquant"):
        cp.corpus(jeu)


def test_lisible_par_test_api(jeu, tmp_path, monkeypatch) -> None:
    import sys
    sortie = tmp_path / "corpus_pilote.json"
    monkeypatch.setattr(sys, "argv", ["x", "--jeu", str(jeu), "--sortie", str(sortie)])
    assert cp.main() == 0
    import test_api
    assert [e["claimId"] for e in test_api.charger_exemples(sortie)] == ["RECLA-0001", "RECLA-0002", "RECLA-0004"]
