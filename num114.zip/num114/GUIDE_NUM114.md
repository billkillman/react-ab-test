# NUM-114 — Référence complète dans Arize AX et concordance des dérives : pas à pas

**Ce que vous aurez à la fin** :

- une **référence** dans Arize AX : les 123 réclamations du pilote, avec tous leurs signaux et leurs embeddings ;
- la preuve qu'Arize **calcule les mêmes dérives que nous** (ou l'écart expliqué), sur trois lots :
  - **E**, le témoin : rien ne doit bouger ;
  - **F**, le glissement de sens : les embeddings bougent, les familles non ;
  - **B**, hors périmètre : les familles et la part hors périmètre bougent ;
- les **seuils confirmés**, prêts pour les moniteurs de NUM-116.

Durée : une journée, dont environ 2 h 30 d'envoi au rythme imposé par le quota hors production.

---

## Le principe en une image

```
 fenêtre 1 : RÉFÉRENCE       fenêtre 2 : E        fenêtre 3 : F         fenêtre 4 : B
 123 réclamations du pilote  100 (témoin)         100 (glissement)      100 (hors périmètre)
 ──────────────┬───────────  ────────┬──────────  ─────────┬──────────  ─────────┬─────────
               │  test_api.py → API → records (signaux + embedding) → Arize AX (ML Models)
               ▼
   Arize AX : « cette période = référence »   ──►   onglets Drift et Embeddings :
                                                     chaque fenêtre comparée à la référence
```

**Pourquoi la référence passe par l'API, et non par un envoi direct.** Deux raisons.

1. **Un fait** : la brique envoie toujours ses records en environnement `PRODUCTION` (valeur fixée dans son backend Arize). Elle ne sait pas envoyer un jeu de pré-production.
2. **Un avantage** : Arize accepte comme référence une **période fixe de production**. Si le pilote passe par l'API, ses signaux sont calculés **par l'API elle-même**, avec ses réglages, son reranker et son modèle d'embeddings. La référence et le trafic sont donc mesurés avec le même instrument, par construction. C'est la condition posée par la décision 4 de la backlog.

**La règle d'or : une fenêtre = un lot, et rien d'autre.** Arize compare une période à la référence. Si deux lots se mélangent dans une même période, ou si quelqu'un appelle l'API en même temps, la mesure ne vaut plus. Notez l'heure de début et de fin de chaque envoi, et laissez au moins 15 minutes entre deux lots.

Les libellés d'écran marqués *(à confirmer)* viennent de la documentation d'Arize et peuvent différer sur votre instance.

---

## Étape 0 — Préparer (20 min)

### 0.1 Vérifier les réglages de l'API

Dans le `.env` de l'API, les trois réglages de calcul doivent être ceux qui ont servi aux références de NUM-109 et NUM-122 :

| Variable | Valeur attendue | Où la retrouver |
|---|---|---|
| `SEUIL_HORS_PERIMETRE` | le seuil de NUM-109 | `reference_signaux/seuils_signaux.json`, clé `seuil_hors_perimetre.seuil` |
| `RERANK_MODEL` | `bge-reranker-v2-m3` (ou celui de NUM-109) | rapport de NUM-109 |
| `EMBEDDING_MODEL` | `bge-m3` | manifeste de NUM-122 (empreinte `ae0d064d457060ea`) |

Sans `SEUIL_HORS_PERIMETRE`, l'API n'envoie pas le motif : la référence serait incomplète.

### 0.2 Relire ce que NUM-109 a déjà établi hors ligne

C'est la partie « hors ligne » du ticket. Elle est déjà calculée : ne relancez rien, relisez `seuils_signaux.json`.

- `seuil_hors_perimetre.auc_couvertes_contre_abstentions` : le score de couverture sépare-t-il les réclamations jugées des abstentions ? Réserve : il n'y a que 8 abstentions.
- Les seuils de chaque signal (clés `seuil_p95`) : notez-les dans le tableau de l'étape 6.

### 0.3 Préparer les fichiers à envoyer

```bash
python -m pytest -q test_num114.py        # 3 passed
python num114_corpus_pilote.py            # → corpus_pilote.json (123 réclamations)
```

Vérifiez aussi que ces trois lots sont présents :

| Lot | Fichier | Produit par |
|---|---|---|
| E | `lots/lot_E_controle.json` | NUM-110 / NUM-123 (`generer_lots.py`) |
| F | `lots/lot_F_glissement_semantique.json` | NUM-123 |
| B | `lots/lot_B_hors_perimetre.json` | NUM-110 |

### 0.4 Lancer l'API

Lancez-la avec ce `.env`, records actifs (`OBS_RECORDS_URI` renseigné). Personne d'autre ne doit l'utiliser pendant les envois.

---

## Étape 1 — Envoyer la référence : fenêtre 1 (≈ 45 min)

Chaque réclamation déclenche trois appels au service : la génération, le reranker et les embeddings. D'où une pause large, pour ne perdre aucun signal sur des erreurs 429.

```bash
date                                    # notez l'heure de DÉBUT
python test_api.py all --fichier corpus_pilote.json --pause 20
date                                    # notez l'heure de FIN
```

**Vérifier dans le terminal** : 123 réclamations envoyées, aucune erreur HTTP.

**Pourquoi 20 secondes.** L'API ne réessaie pas le reranker ni les embeddings (un seul essai, 5 s de délai) : un 429 fait perdre le signal de cette réclamation. Sur la référence, un trou se paierait ensuite sur toutes les comparaisons.

---

## Étape 2 — Vérifier que la référence est complète dans AX (15 min)

| | |
|---|---|
| **Où** | **ML Models** → modèle `recla-assistant` (valeur de `OBS_MODEL_ID`) |
| **Régler** | La période sur la fenêtre 1 (heures notées à l'étape 1) |
| **Vérifier** | ・ **123** prédictions sur la période (les records mettent quelques minutes à apparaître) |
| | ・ Les features présentes : `longueur_mots`, `part_majuscules`, `nb_exclamations`, `langue`, `encodage_suspect`, `nb_jetons_anonymisation`, `motif`, `famille`, `score_couverture` |
| | ・ La feature d'embedding `embedding`, avec son texte |
| | ・ Dans l'onglet de qualité des données *(libellé à confirmer)* : le taux de valeurs manquantes de `motif`, `score_couverture` et `embedding` **≤ 3 %** |

**Si plus de 3 % de valeurs manquent**, des signaux ont été perdus sur des 429. Ne bricolez pas : refaites l'étape 1 avec `--pause 30`, dans une **nouvelle** fenêtre, et utilisez cette nouvelle fenêtre comme référence.

---

## Étape 3 — Désigner la référence (10 min)

| | |
|---|---|
| **Où** | Modèle `recla-assistant` → configuration du modèle → **Baseline** *(emplacement à confirmer)* |
| **Faire** | Choisissez une référence **de production**, sur une **période fixe** *(fixed time range)* égale à la fenêtre 1 : début et fin notés à l'étape 1, à la minute près. Ne prenez pas de fenêtre glissante : la référence doit rester celle du pilote. |
| **Vérifier** | Les onglets **Drift** et **Embeddings** affichent désormais « baseline » et s'appuient sur 123 lignes. |

Choisissez aussi la **métrique de dérive PSI**, si le réglage est proposé : c'est la formule de NUM-109. Arize propose aussi KL, JS et KS ; la documentation ne précise pas laquelle s'applique par défaut.

---

## Étape 4 — Lot E, le témoin : rien ne doit bouger (fenêtre 2, ≈ 35 min)

Le lot E est tiré du pilote lui-même : il doit ressembler à la référence.

```bash
date ; python test_api.py all --fichier lots/lot_E_controle.json --pause 20 ; date
```

| | |
|---|---|
| **Où** | Onglet **Drift**, période = fenêtre 2 |
| **Lire** | La dérive (PSI) de chaque feature, la part de `Hors périmètre` dans la distribution de `motif`, puis, dans l'onglet **Embeddings** *(libellé à confirmer)*, la distance de la feature `embedding` |
| **Attendu** | ・ Toutes les dérives **sous leur seuil** |
| | ・ Distance d'embeddings proche de **0,0295** (seuil 0,0800) |
| | ・ Part hors périmètre proche de **0,09** (seuil 0,14) |

---

## Étape 5 — Lot F, le glissement de sens (fenêtre 3, ≈ 35 min)

```bash
date ; python test_api.py all --fichier lots/lot_F_glissement_semantique.json --pause 20 ; date
```

| Signal | Valeur hors ligne (NUM-123) | Seuil | Attendu dans AX |
|---|---|---|---|
| Distance d'embeddings | **0,1586** | 0,0800 | **au-dessus** du seuil : c'est la preuve de ce que le signal 4 apporte |
| PSI des familles | 0,069 | 0,2133 | **sous** le seuil : les thèmes ne bougent pas |
| Part hors périmètre | 0,17 | 0,14 | au-dessus : réaction **consignée**, ce n'est pas un échec (décision 6) |

Profitez-en pour découvrir la **vue UMAP** : depuis la courbe de dérive de `embedding`, ouvrez la projection et repérez le groupe formé par F. L'exploration complète est prévue en NUM-118.

---

## Étape 6 — Lot B, hors périmètre (fenêtre 4, ≈ 35 min)

```bash
date ; python test_api.py all --fichier lots/lot_B_hors_perimetre.json --pause 20 ; date
```

**Attendu** :
- PSI des familles **au-dessus** de 0,2133 ;
- part hors périmètre **au-dessus** de 0,14 ;
- distance d'embeddings probablement au-dessus aussi : un thème nouveau change le sens.

---

## Étape 7 — Conclure : le tableau de concordance (45 min, avec le Tech Lead)

Remplissez ce tableau dans le ticket :

| Signal | Lot | Nous (hors ligne) | Arize | Écart | Explication si écart | Seuil retenu pour NUM-116 |
|---|---|---|---|---|---|---|
| Distance d'embeddings | E | 0,0295 | | | | 0,0800 ? |
| Distance d'embeddings | F | 0,1586 | | | | |
| PSI des familles | F | 0,069 | | | | 0,2133 ? |
| PSI des familles | B | (au-dessus du seuil) | | | | |
| Part hors périmètre | E / F / B | 0,09 / 0,17 / — | | | | 0,14 ? |
| Part d'encodage suspect | E | (seuil NUM-109) | | | | |
| Langue | E | aucune langue nouvelle | | | | |

**Lire les écarts.** Un écart n'est pas un échec s'il s'explique. Les causes connues :

| Écart constaté | Cause probable | Que faire |
|---|---|---|
| PSI d'une feature **numérique** (longueur, part de majuscules, score de couverture) différent du nôtre | Arize découpe les valeurs en tranches à sa façon ; NUM-109 utilise 10 tranches sur les centiles de la référence | Garder le seuil d'Arize, recalibré sur E : c'est lui qui alertera |
| PSI des **familles** légèrement différent | lissage des catégories absentes (NUM-109 : 0,0001) | Négligeable si l'ordre de grandeur et le verdict (au-dessus ou sous le seuil) concordent |
| Distance d'embeddings différente | définition de la distance, centroïdes calculés sur des vecteurs normalisés ou non | Si E reste sous le seuil et F au-dessus avec la même marge, garder la logique et ajuster le seuil à la distance d'Arize |
| Signaux manquants sur une fenêtre | 429 sur le reranker ou les embeddings | Renvoyer ce lot dans une nouvelle fenêtre, avec une pause plus longue |

**La règle de décision pour chaque signal :**
- **validé** si E reste sous le seuil et si le lot qui doit le déclencher (F ou B) le dépasse, dans Arize ;
- **seuil ajusté** si le verdict est bon mais la valeur d'Arize s'écarte de la nôtre : on prend le seuil sur l'échelle d'Arize ;
- **écarté** si Arize ne le distingue pas de façon fiable : à justifier.

---

## DoD

- [ ] Référence en place dans Arize AX : période fixe de production, 123 lignes, embeddings compris, au plus 3 % de valeurs manquantes.
- [ ] Réglages de calcul de l'API identiques à ceux des références (étape 0.1). La référence étant calculée par l'API, cette condition vaut ensuite par construction.
- [ ] Tableau de concordance rempli pour E, F et B ; chaque signal validé, ajusté ou écarté, avec sa justification.
- [ ] Seuils transmis à NUM-116.
- [ ] Relecture par le Tech Lead.

## Pièges à connaître

| Piège | Conséquence | Parade |
|---|---|---|
| Autre trafic sur l'API pendant un envoi | la fenêtre est polluée, la mesure ne vaut plus | prévenir l'équipe ; une fenêtre = un lot |
| Le prompt change de version (NUM-50) | les records portent une autre `model_version` | vérifier que la référence et les fenêtres sont lues sur la même version, ou sur toutes les versions |
| Les 500 exemples de NUM-34, déjà envoyés en production | ils pollueraient une référence mal bornée | borner la référence à la minute près (étape 3) |
| Lot A (surface) | absent de ce ticket | il est éprouvé dans NUM-118, avec les moniteurs |

## Fonctionnalités d'Arize AX éprouvées

| Fonctionnalité | Étape |
|---|---|
| ML Models : records, features, feature d'embedding | 2 |
| Qualité des données (valeurs manquantes) | 2 |
| Référence (baseline) sur une période fixe de production | 3 |
| Drift : dérive par feature, choix de la métrique, comparaison des distributions | 3 à 6 |
| Embeddings : distance de dérive, vue UMAP | 4 à 6 |

## Les fichiers

| Fichier | Rôle |
|---|---|
| `num114_corpus_pilote.py` | réunit les 3 jeux du NUM-14 au format de `test_api.py` (`corpus_pilote.json`) |
| `test_num114.py` | 3 tests, dont la lecture du fichier par `test_api.py` |

Réutilisés sans modification : `test_api.py`, l'API (INSTR v2), les lots de NUM-110 et NUM-123, `seuils_signaux.json` (NUM-109).
