"""Prépare le corpus du pilote pour l'envoyer à l'API avec test_api.py (NUM-114).

Les 123 réclamations du pilote (jeux du NUM-14, déjà anonymisés) deviennent la fenêtre de
référence d'Arize : on les fait passer par l'API, qui calcule et envoie leurs signaux avec
ses propres réglages, puis on désigne cette période comme référence dans Arize AX.

    python num114_corpus_pilote.py                     # lit jeu_jugements/, écrit corpus_pilote.json
    python num114_corpus_pilote.py --jeu autre_dossier

Le fichier produit a le format attendu par test_api.py : une liste de {claimId, claimVerbatim}.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

#: Les trois jeux du NUM-14, dans l'ordre (mêmes noms qu'en NUM-109).
FICHIERS = {"calibrage": "recla_jugements_calibrage.csv", "mesure": "recla_jugements_mesure.csv",
            "abstentions": "recla_abstentions.csv"}


def corpus(dossier: Path) -> list[dict]:
    lignes = []
    for source, nom in FICHIERS.items():
        chemin = dossier / nom
        if not chemin.exists():
            raise SystemExit(f"Fichier manquant : {chemin}")
        with chemin.open(encoding="utf-8", newline="") as flux:
            for ligne in csv.DictReader(flux):
                texte = (ligne.get("claim_verbatim") or "").strip()
                if texte:
                    lignes.append({"claimId": ligne["claim_id"], "claimVerbatim": texte, "type": source})
    identifiants = [l["claimId"] for l in lignes]
    if len(set(identifiants)) != len(identifiants):
        raise SystemExit("Identifiants en double entre les jeux : la référence compterait deux fois une réclamation.")
    return lignes


def main() -> int:
    parser = argparse.ArgumentParser(description="Corpus du pilote au format de test_api.py (NUM-114).")
    parser.add_argument("--jeu", type=Path, default=Path("jeu_jugements"), help="dossier produit en NUM-14")
    parser.add_argument("--sortie", type=Path, default=Path("corpus_pilote.json"))
    args = parser.parse_args()
    lignes = corpus(args.jeu)
    args.sortie.write_text(json.dumps(lignes, ensure_ascii=False, indent=2), encoding="utf-8")
    par_source = {s: sum(l["type"] == s for l in lignes) for s in FICHIERS}
    print(f"{len(lignes)} réclamations écrites dans {args.sortie} : "
          + ", ".join(f"{n} {s}" for s, n in par_source.items()))
    return 0


if __name__ == "__main__":
    sys.exit(main())
